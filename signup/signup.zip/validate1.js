function check() {
    const id = document.getElementById("id");
    const pass = document.getElementById("pass");
    const jumin1 = document.getElementById("jumin1");
    const jumin2 = document.getElementById("jumin2");
    const email = document.getElementById("email");
    const domain = document.getElementById("domain");
    const post = document.getElementById("post1");
    const address = document.getElementById("address");
    const intro = document.getElementById("intro");

    // ID
    if (id.value.trim() === "") {
        alert("ID를 입력하세요")
        id.focus();
        return false;
    }

    //Password
    if (pass.value.trim() === "") {
        alert("Password를 입력하세요")
        pass.focus();
        return false;
    }

    // 주민번호
    if (jumin1.value.trim() === "") {
        alert("주민번호 앞자리를 입력하세요")
        jumin1.focus();
        return false;
    }
    if (jumin1.value.length !== 6) {
        alert("주민번호 앞자리 6자리를 입력하세요");
        jumin1.value = "";
        jumin1.focus();
        return false;
    }
    if (jumin2.value.trim() === "") {
        alert("주민번호 뒷자리를 입력하세요");
        jumin2.focus();
        return false;
    }
    if (jumin2.value.length !== 7) {
        alert("주민번호 뒷자리 7자리를 입력하세요");
        jumin2.value = "";
        jumin2.focus();
        return false;
    }

    //이메일
    if (email.value.trim() === "") {
        alert("E-Mail을 입력하세요")
        id.focus();
        return false;
    }
    if (domain.value.trim() === "") {
        alert("E-Mail을 입력하세요")
        id.focus();
        return false;
    }

    // 우편번호
    if (post.value.trim() === "") {
        alert("우편번호를 입력하세요")
        post.focus();
        return false;
    }

    // 주소
    if (address.value.trim() === "") {
        alert("주소를 입력하세요")
        address.focus();
        return false;
    }

    // 자기소개
    if (intro.value.trim() === "") {
        alert("자기소개를 입력하세요")
        intro.focus();
        return false;
    }

    const gender1 = document.getElementById("gender1");
    const gender2 = document.getElementById("gender2");
    if (!gender1.checked && !gender2.checked) {
        alert("성별을 체크해주세요")
        gender1.focus();
        return false;
    }

    let cnt = 0;
    const hobbys = document.getElementsByName("hobby");
    for (let i = 0; i < hobbys.length; i++) {
        if (hobbys[i].checked) {
            cnt++;
        }
    }
    if (cnt < 2) {
        alert("취미를 2개 이상 선택하세요")
        return false;
    }
}

function idcheck() {
    const id = document.getElementById("id");

    // ID
    if (id.value.trim() === "") {
        alert("ID를 입력하세요")
        id.focus();
        return false;
    }

    window.open("idcheck.html", "아이디 중복 검사", "width=300, height=250");
}

function move() {

}

function domain1() {

}

function post() {
    window.open("post.html", "우편번호 검색", "width=400, height=500");
}